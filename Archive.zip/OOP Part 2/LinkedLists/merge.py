from singlylist_class import SinglyList

def merge(train1, train2):
    train2.head



if __name__ == "__main__":