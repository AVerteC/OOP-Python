class FirstClass:
    def hello(self, name, number):
        print("Method hello in FirstClass is called")
        print("Hello " + name +", your number is "+ str(number))