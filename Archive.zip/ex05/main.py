from second_class import SecondClass

if __name__ == "__main__":
    sc = SecondClass("alanchen", "swimming")
    x = sc.get_hobby()
    print("Your hobby is " + str(x))
