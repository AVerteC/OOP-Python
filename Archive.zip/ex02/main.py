from second_class import SecondClass


if __name__ == '__main__':
    sc = SecondClass("alanchen")

