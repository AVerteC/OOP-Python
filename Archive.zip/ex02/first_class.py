class FirstClass(object):
    def __init__(self):
        self.greeting = greeting()

    def greeting(self, name):
            print("Hello" + " " + name)




