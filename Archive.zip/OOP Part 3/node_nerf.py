class Node(object):
    def __init__(self, value, next = None):
        self.data = value
        self.next = next
