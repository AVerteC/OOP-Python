class FirstClass:

    def __init__(self):
        print("Hello World")
