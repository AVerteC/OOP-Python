class FirstClass:

    #def __init__(self):

        def welcome(self):
            print("Hello World")
