class FirstClass():

    def say_hello(self, name):
        print("Method say_hello in FirstClass is called")
        print("Hello" + " " + name)
